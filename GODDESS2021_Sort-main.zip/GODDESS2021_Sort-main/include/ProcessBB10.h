#ifndef ProcessBB10_h
#define ProcessBB10_h

#include "TypeDef.h"

#include <iostream>
#include <vector>

BB10DetRaw ProcessBB10(std::vector<BB10Hit> BB10Hit_);

#endif // ProcessBB10_h
