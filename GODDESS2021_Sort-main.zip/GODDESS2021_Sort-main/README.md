# GODDESSSort
* This is a modified version of the GODDESS Sort code written by Josh Hooker (https://github.com/joshhooker/goddessSort)

* To unpack the GRETINA data, this sort code calls the program unpackGRETINA that was written by Heather Crawford (https://github.com/GRETINA-LBNL/gretina-unpack)
