#ifndef GLOBAL_HH
#define GLOBAL_HH

typedef unsigned short WORD;
typedef unsigned char  BYTE;

typedef unsigned short UINT16;
typedef signed short INT16;



#endif
